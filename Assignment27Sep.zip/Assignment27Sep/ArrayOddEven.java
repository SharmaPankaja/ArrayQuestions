package Assignment27Sep;

public class ArrayOddEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = { 11, 82, 93, 64, 56 };
		int even = 0, odd = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] % 2 == 0)
				even++;
			else
				odd++;
		}
		System.out.println("Total number of even number is " + even);
		System.out.println("Total number of odd number is " + odd);
	}

}
