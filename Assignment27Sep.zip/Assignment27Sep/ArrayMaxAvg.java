package Assignment27Sep;

public class ArrayMaxAvg {
	public void max()
	{
		int[] a= {1,2,3,4,5,6};
		int max=a[0];
		for(int i=1;i<a.length;i++)
		{
			if(a[i]>max)
			{
				max=a[i];
			}
		}
		
		System.out.println("Max is: "+max);
		
		
	}
	public void Average()
	{
		int[] a= {1,2,3,4,5,6};
		int sum=0;
		for(int i:a)
		{
			sum+=i;
		}
		double avg=sum/a.length;
        System.out.println("Average= "+avg);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayMaxAvg average = new ArrayMaxAvg();
		average.Average();
		average.max();
	}

}
