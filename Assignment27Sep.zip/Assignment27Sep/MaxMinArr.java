package Assignment27Sep;
import java.util.Arrays;

public class MaxMinArr {
	private 
	int max=0,min=0;
	
	public void maxmin()
	{
		int[] arr= {123,24,33,422,5,45};
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+",");
		}
		Arrays.sort(arr);
		min=arr[1];
		max=arr[4];
	
		System.out.println("Second Min = "+min);
		System.out.println("SEcond max = "+max);
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MaxMinArr mm= new MaxMinArr();
		mm.maxmin();

	}

}
