package Assignment27Sep;
import java.util.*;

public class SumOfDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int sum=0;
		int num,digit;
		System.out.println("Enter a number");
		num=sc.nextInt();
		while(num>0)
		{
			digit=num%10;
			sum=sum+digit;
			num=num/10;
			
		}
		System.out.println("Sum of digits of number = "+sum);
		

	}

}
