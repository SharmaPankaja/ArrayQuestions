package Assignment27Sep;

public class ArrayRev {
	public void Revarr()
	{
		int[] arr= {56,62,53,44,25,6};
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+",");
		}
		int start=0;
		int end=arr.length-1;
		
		while(start<end)
		{
			int temp=arr[start];
			arr[start]=arr[end];
			arr[end]=temp;
			start++;
			end--;
			
		}
		System.out.println("Reverse array: ");
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+",");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayRev arrayrev= new ArrayRev();
		arrayrev.Revarr();


	}

}
